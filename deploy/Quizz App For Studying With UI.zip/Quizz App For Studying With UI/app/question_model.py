class Question:
    def __init__(self, q_text, q_answer, q_options):
        self.text = q_text
        self.answer = q_answer
        self.options = q_options